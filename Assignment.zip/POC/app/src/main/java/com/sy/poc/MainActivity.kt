package com.sy.poc

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.sy.poc.api.MovieApiService
import com.sy.poc.api.MovieRepository
import com.sy.poc.model.Movie
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

// MainActivity.kt
class MainActivity : AppCompatActivity() {
    private lateinit var viewModel: MovieViewModel
    private lateinit var gridLayout: GridLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        gridLayout = findViewById(R.id.gridLayout)

        val movieApiService = Retrofit.Builder()
            .baseUrl("https://api.themoviedb.org/3/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(MovieApiService::class.java)

        val movieRepository = MovieRepository(movieApiService)
        viewModel = ViewModelProvider(this, ViewModelProvider.AndroidViewModelFactory.getInstance(application)).get(MovieViewModel::class.java)

        // Example usage: fetch popular movies
        viewModel.getPopularMovies(1)

        viewModel.movies.observe(this, Observer { movies ->
            // Update UI with movies data
            updateGridLayout(movies)
        })
    }

    private fun updateGridLayout(movies: List<Movie>) {
        // Clear existing views
        gridLayout.removeAllViews()

        // Add new views for each movie
        movies.forEach { movie ->
            val itemView = LayoutInflater.from(this).inflate(R.layout.grid_item_movie, gridLayout, false)

            // Set movie data to itemView
            val imageViewPoster = itemView.findViewById<ImageView>(R.id.imageViewPoster)
            val textViewTitle = itemView.findViewById<TextView>(R.id.textViewTitle)
            val textViewRating = itemView.findViewById<TextView>(R.id.textViewRating)

            // Set data to views
            textViewTitle.text = movie.title
            textViewRating.text = "Rating: ${movie.rating}"
            // Load image using Glide or Picasso library
            // Glide.with(this).load(movie.posterPath).into(imageViewPoster)

            gridLayout.addView(itemView)
        }
    }
}
