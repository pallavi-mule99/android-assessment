package com.sy.poc

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sy.poc.api.MovieRepository
import com.sy.poc.model.Movie
import kotlinx.coroutines.launch

// MovieViewModel.kt
class MovieViewModel(private val movieRepository: MovieRepository) : ViewModel() {
    private val _movies = MutableLiveData<List<Movie>>()
    val movies: LiveData<List<Movie>> = _movies

    private val _error = MutableLiveData<String>()
    val error: LiveData<String> = _error

    fun getPopularMovies(page: Int) {
        viewModelScope.launch {
            try {
                val response = movieRepository.getPopularMovies(page)
                if (response.isSuccessful) {
                    val movieListResponse = response.body()
                    if (movieListResponse != null) {
                        _movies.value = movieListResponse.results
                    }
                } else {
                    _error.value = "Failed to fetch popular movies: ${response.message()}"
                }
            } catch (e: Exception) {
                _error.value = "Error: ${e.message}"
            }
        }
    }
}
