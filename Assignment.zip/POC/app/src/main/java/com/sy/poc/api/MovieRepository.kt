package com.sy.poc.api

import com.sy.poc.model.Movie
import retrofit2.Response

class MovieRepository(private val movieApiService: MovieApiService) {
    suspend fun getPopularMovies(page: Int): Response<List<Movie>> {
        return movieApiService.getPopularMovies(API_KEY, page)
    }

    companion object {
        private const val API_KEY = "api_key_here"
    }
}
